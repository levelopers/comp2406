/*
JSON formatted data can be read directly from a .json file.
This is very convenient for configuration data etc.
*/
let obj1 = require("./data.json")
console.log(obj1)
let obj2 = require("./myObj.json")
console.log(obj2)
